package com.lab.llm_platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LlmPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(LlmPlatformApplication.class, args);
	}

}
